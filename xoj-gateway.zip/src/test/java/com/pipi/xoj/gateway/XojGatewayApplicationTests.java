package com.pipi.xoj.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XojGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
